<?php 
class Error_Controller extends CI_Controller {

    public function index() 
    {
        
        $this->load->view('error_viewer');
    }
}

?>