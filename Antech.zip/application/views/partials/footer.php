<footer class='flex'>
    <p> ©2021 ANTECH® ALL RIGHTS RESERVED.</p>
    <a href="https://www.antechdiagnostics.com/privacy-policy" target='_blank'>PRIVACY POLICY</a>
    <a href='https://www.antechdiagnostics.com/terms-of-use' target='_blank'>TERMS OF USE</a>
</footer>
