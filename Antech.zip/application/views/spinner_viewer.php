<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
    <title>Sending...</title>
</head>
<body>
    <div id="spinner"></div> 
</body>

<script>
    //const spinner = document.getElementById("spinner");

    // function showSpinner() {
    // spinner.classList.add("show");
    // setTimeout(() => {
    //     spinner.classList.remove("show");
    // }, 5000);
    // }

    // // function hideSpinner() {
    // //   spinner.className = spinner.className.replace("show", "");
    // // }


    // showSpinner()
    

    </script>
</html>